package com.example.milestone;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    Button btn_add;

    MyApplication myApplication = (MyApplication) this.getApplication();

    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    List<Contact> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactList = myApplication.getContactList();

        btn_add = findViewById(R.id.btn_add);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddEditContact.class);
                startActivity(intent);
            }
        });

        recyclerView = (RecyclerView) findViewById(R.id.rv_list);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        // specify an adapter (see also next example)
        mAdapter = new ContactAdapter(contactList, MainActivity.this);
        recyclerView.setAdapter(mAdapter);

        for (int x = 0; x < contactList.size(); x++) {
            String text = Integer.toString(contactList.get(x).getContactID()) + "," +
                          Integer.toString(contactList.get(x).getPhoneNum()) + "," +
                          contactList.get(x).getName() + "," +
                          contactList.get(x).getPhotoURL() +  "," +
                          Integer.toString(contactList.get(x).getLocation().getStreetNumber()) + "," +
                          contactList.get(x).getLocation().getStreetName() + "," +
                          contactList.get(x).getLocation().getCity() + "," +
                          contactList.get(x).getLocation().getState();

            try {
                saveToTextFile(text);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void saveToTextFile(String text) throws IOException {
        File contactFile = new File("F:\\Android Studio\\Milestone\\app\\src\\main\\java\\com\\example\\milestone\\MainActivity.java");
        FileWriter fw = new FileWriter(contactFile, true);
        PrintWriter pw = new PrintWriter(fw);

        pw.println(fw);
        pw.close();
    }
}