package com.example.milestone;

public class Contact {
    private int contactID;
    private int phoneNum;
    private String name;
    private String photoURL;
    private Location location = new Location();

    public Contact() {

    }

    public Contact(int contactID, int phoneNum, String name, String photoURL, Location location) {
        this.contactID = contactID;
        this.phoneNum = phoneNum;
        this.name = name;
        this.photoURL = photoURL;
        this.location = location;
    }

    @Override
    public String toString() {
        return "Contact{" +
                "contactID=" + contactID +
                ", phoneNum=" + phoneNum +
                ", name='" + name + '\'' +
                ", photoURL='" + photoURL + '\'' +
                ", location=" + location.toString() +
                '}';
    }

    public int getContactID() {
        return contactID;
    }

    public void setContactID(int contactID) {
        this.contactID = contactID;
    }

    public int getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(int phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhotoURL() {
        return photoURL;
    }

    public void setPhotoURL(String photoURL) {
        this.photoURL = photoURL;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }
}
