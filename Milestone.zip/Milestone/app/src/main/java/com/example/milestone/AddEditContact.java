package com.example.milestone;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.List;

public class AddEditContact extends AppCompatActivity {
    Button btn_ok, btn_cancel;
    EditText et_name, et_number, et_photoURL, et_streetNumber, et_streetName, et_city, et_state;
    TextView tv_contactID;

    int id;

    List<Contact> contactList;
    MyApplication myApplication = (MyApplication) this.getApplication();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_edit_contact);

        contactList = myApplication.getContactList();

        btn_ok = findViewById(R.id.btn_ok);
        btn_cancel = findViewById(R.id.btn_cancel);
        et_name = findViewById(R.id.et_name);
        et_number = findViewById(R.id.et_number);
        et_photoURL = findViewById(R.id.et_photoURL);
        et_streetNumber = findViewById(R.id.et_streetNumber);
        et_streetName = findViewById(R.id.et_streetName);
        et_city = findViewById(R.id.et_city);
        et_state = findViewById(R.id.et_state);
        tv_contactID = findViewById(R.id.tv_idNum);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1);
        Contact contact = null;

        if (id >= 0) {
            for (Contact c: contactList) {
                if (c.getContactID() == id) {
                    contact = c;
                }
            }
            et_name.setText(contact.getName());
            et_number.setText(String.valueOf(contact.getPhoneNum()));
            et_photoURL.setText(contact.getPhotoURL());
            et_streetNumber.setText(String.valueOf(contact.getLocation().getStreetNumber()));
            et_streetName.setText(contact.getLocation().getStreetName());
            et_city.setText(contact.getLocation().getCity());
            et_state.setText(contact.getLocation().getState());
            tv_contactID.setText(String.valueOf(id));
        }
        else {

        }

        btn_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddEditContact.this, MainActivity.class);
                startActivity(intent);

                if (id >= 0) {
                    Location updatedLocation = new Location(Integer.parseInt(et_streetNumber.getText().toString()), et_streetName.getText().toString(), et_city.getText().toString(), et_state.getText().toString());
                    Contact updatedContact = new Contact(id, Integer.parseInt(et_number.getText().toString()), et_name.getText().toString(), et_photoURL.getText().toString(), updatedLocation);
                    contactList.set(id, updatedContact);
                }
                else {
                    int nextID = myApplication.getNextID();
                    Location newLocation = new Location(Integer.parseInt(et_streetNumber.getText().toString()), et_streetName.getText().toString(), et_city.getText().toString(), et_state.getText().toString());
                    Contact newContact = new Contact(nextID, Integer.parseInt(et_number.getText().toString()), et_name.getText().toString(), et_photoURL.getText().toString(), newLocation);
                    contactList.add(newContact);
                    myApplication.setNextID(nextID++);
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddEditContact.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
