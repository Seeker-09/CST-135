package com.example.milestone;

import android.app.Application;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MyApplication extends Application {
    private static List<Contact> contactList = new ArrayList<Contact>();
    private static int nextID = contactList.size();

    File path = MyApplication.this.getFilesDir();

    public MyApplication() throws IOException {
        fillContactList();
    }

    private void fillContactList() throws IOException {
        File contactFile = new File(path, "Contacts.txt");
        Scanner s = new Scanner(contactFile);

        while (s.hasNext()) {
            String line = s.nextLine();
            String[] items = new String[8];
            items = line.split(",");

            int idNum = Integer.parseInt(items[0]);
            int phoneNum = Integer.parseInt((items[1]));
            String name = items[2];
            String photoURL = items[3];
            int streetNum = Integer.parseInt(items[4]);
            String streetName = items[5];
            String city = items[6];
            String state = items[7];

            Location newLocation = new Location(streetNum, streetName, city, state);
            Contact newContact = new Contact(idNum, phoneNum, name, photoURL, newLocation);
            contactList.add(newContact);
        }

        FileWriter fw = new FileWriter(contactFile, false);
        PrintWriter pw = new PrintWriter(fw);
        pw.print("");
        pw.close();
    }

    public static List<Contact> getContactList() {
        return contactList;
    }

    public static void setContactList(List<Contact> contactList) {
        MyApplication.contactList = contactList;
    }

    public static int getNextID() {
        return nextID;
    }

    public static void setNextID(int nextID) {
        MyApplication.nextID = nextID;
    }
}
